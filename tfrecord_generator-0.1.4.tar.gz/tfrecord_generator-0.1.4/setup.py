from setuptools import setup, find_packages
#cd to this directory and run: python setup.py sdist to create a source distribution
setup(
    name='tfrecord_generator',
    version='0.1.4',
    packages=find_packages(),
    install_requires=[],
    author='Yehonatan Gurevich',
    description='Generator for tfrecord files',
    url='',
    classifiers=[
        
    ],
)
