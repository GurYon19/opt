import imp
import tensorflow as tf
import pandas as pd
from tfrecord_generator.dg_utils.label_utils import set_label,two_d_to_one_d_label
from tfrecord_generator.dg_utils.preproc import normalize_list
class TFRecordGenerator():
    """
    class to generate tfrecord files from csv files

    """
    def __init__(self,csv_file,tfrecord_path,column_names,label_name,new_label_name,new_label_func,max_window_size = 0, window_sizes  = {}) -> None:
        
        self.csv_file = csv_file
        self.tfrecord_path = tfrecord_path
        self.column_names = column_names
        self.new_column_names = column_names.copy()
        self.label_name = label_name
        self.new_label_name = new_label_name
        self.new_label_func = new_label_func

        self.csv_dict,self.col_lens = self.get_col_lens_and_dict()
        self.window_sizes = window_sizes
        
        

        #if max window size is not set, set it to the max window
        self.max_window_size = max_window_size if max_window_size > 0 else max(window_sizes.values())
        self.max_col_len, \
        self.max_col_len_rounded, \
        self.windows_number            = \
                                        self.set_max_col_and_windows_number()
        
        
        self.col_lens_rounded = self.set_col_lens_rounded()
        #list of dicts, each dict is a window.key is sensor name value is a list(window ) of values 
        self.samples_windows = [] 
        self.old_samples_windows = [] # used for get window_size before label calculation

        #window size for each colum based on max window length
        self.window_sizes =  window_sizes if window_sizes else self.set_window_sizes()
        #print(self.window_sizes)
        self.new_label_window_size = self.window_sizes.copy()

    def get_old_label_window_size(self):
        return self.window_sizes
    
    def windows_to_tfrecords(self):
        """
        write the dictionary from csv to tfrecord
        """

        with tf.io.TFRecordWriter(self.tfrecord_path) as writer:
            for i in range(self.windows_number):
                example = tf.train.Example(features=tf.train.Features
                (
                    feature=
                    {
                    column_name: tf.train.Feature(
                    float_list=tf.train.FloatList(
                    value=[float(i) for i in value]))

                    for column_name, value in self.samples_windows[i].items() 
                    }
                ) )                     
                example = example.SerializeToString()
                writer.write(example)

    def convert_to_tfrecord(self):
        self.create_list_of_windows() 
        self.windows_to_tfrecords()

    def set_max_col_and_windows_number(self):
        max_col_len = max(self.col_lens.values())
        windows_number = max_col_len//self.max_window_size
        max_col_len_rounded = windows_number*self.max_window_size # remove remainder 
        assert windows_number  > 0 ,f'windows number is {windows_number} , it should be at least 1'
        return max_col_len,max_col_len_rounded,windows_number
                          

    def get_col_lens_and_dict(self):
        return self.__read_csv()
    
    def get_col_lens(self):
        _,col_lens = self.__read_csv()
        return col_lens
    
    def get_dict_from_csv(self):
        csv_dict,_ = self.__read_csv()
        return csv_dict

    def __normalize_list(self,list_to_norm):
        return normalize_list(list_to_norm=list_to_norm)
        
    def check_df(self,df,csv_file):
        if df.empty:
            raise ValueError(f'{self.csv_file} is empty')
    def __read_csv(self):
        """
        extract just relevant columns from CSV 
        returns: CSV dictionary, coloumn lengths 
        """
        df = pd.read_csv(self.csv_file)
        self.check_df(df,self.csv_file)
        dict_from_csv = {}
        values_lengths = {}
        for col in self.column_names:
            dict_from_csv[col] = df[col].tolist()[1:]
            dict_from_csv[col] = [x for x in dict_from_csv[col] if str(x) != "nan"]
            p = dict_from_csv[col]
            if col not in self.label_name:
                dict_from_csv[col] = self.__normalize_list(p)
            values_lengths[col] = len(dict_from_csv[col])
            assert values_lengths[col] > 0, f"Empty column {col} in csv file"
        return dict_from_csv, values_lengths

    def set_col_lens_rounded(self):
        col_lens_rounded = {}
        for key,length in self.col_lens.items():
            if length == self.max_col_len:
                col_lens_rounded[key] = self.max_col_len_rounded
            else:
                if self.window_sizes:
                    window_size = self.window_sizes[key]
                else:
                    window_size = round(self.col_lens[key]/self.windows_number)
                number_of_windows = length//window_size
                col_lens_rounded[key] = number_of_windows*window_size
        return col_lens_rounded
    
    def set_window_sizes(self):
        window_sizes = {}
        #calculate the relative window sizes - window size depends on the number of samples in each coloumn
        for key, _  in self.col_lens_rounded.items():
            window_sizes[key] = self.col_lens_rounded[key]//self.windows_number  
            #a=self.col_lens_rounded[key]//self.windows_number
            #b=self.col_lens_rounded[key]/self.windows_number  
            assert self.col_lens_rounded[key]//self.windows_number  == int(self.col_lens_rounded[key]/self.windows_number) ,"col_lens error-generator"
        return window_sizes
    
    def create_list_of_windows(self):
        #list of dicts [{},{},.......,{}] ,each dict is a window of samples from the csv file 
        for i in range(self.windows_number): #input lengths can differ, safety measurement
            valid=True
            window_dict = {}
            #create a window
            for key,windows_size in self.window_sizes.items():
                if key not in self.label_name: #each sample is a window
                    window_dict[key] = self.csv_dict[key][i*windows_size:(i+1)*windows_size]
                    valid = (len(window_dict[key]) == windows_size and valid)
                else: #calculate label from the last window of samples in the label coloum
                    window_dict[key] = self.csv_dict[key][i*windows_size:(i+1)*windows_size]
            
            if valid:        
                if self.new_label_func:
                    old_window_dict = window_dict.copy()
                    self.old_samples_windows.append(old_window_dict)
                    values_of_old_labels = [value for key, value in window_dict.items() if key in self.label_name]
                    for old_label in self.label_name:
                        #remove old_labels from window_dict
                        window_dict.pop(old_label)
                    #function that will calculate the label from the list of labels
                    for new_label,new_label_func in zip(self.new_label_name,self.new_label_func):
                        window_dict[new_label] = new_label_func(values_of_old_labels)
                #add this dict as windows
                self.samples_windows.append(window_dict)
            else:
                self.windows_number -= 1
        #keys before calculation of new label 
        # for key,value in self.old_samples_windows[0].items():
        #     new_window_sizes[key] = len(value)
        # self.window_sizes = new_window_sizes

        if self.new_label_func:
            self.new_label_window_size = {}
            for key,value in window_dict.items():
                self.new_label_window_size[key] = len(value)

    def get_new_label_window_size(self):
        return self.new_label_window_size


