import os
from os.path import isfile, join
import tensorflow as tf

from tfrecord_generator.TFRecordGenerator import TFRecordGenerator

class TFRecordManager():
    """
        This class is used to manage the tfrecord files.
        This class is responsible for converting csv files to tfrecord files.
        It creates TFRecordGenerator for each csv file.
        *IMPORTANT*: This class assumes that all csv files have the same format. though it may have different lengths.         
    """

    def __init__(self,csv_path,tfrecord_path,new_label_name,new_label_func,batch_size = 1,max_window_size = -1,window_sizes = {},labeled=True,features =[],label_name ='') -> None:
        self.csv_path = csv_path
        self.csv_files = self.get_csv_filenames()
        
        self.tfrecord_path = tfrecord_path
        self.labeled = labeled
        self.label_name = label_name
        self.batch_size = batch_size
        self.max_window_size = max_window_size 
        self.window_sizes = window_sizes
        self.window_sizes_for_extract_fn = window_sizes.copy()
        self.new_label_func = new_label_func
        self.label_name_for_extract_fn = new_label_name 

        self.column_names = self.get_column_names(self.csv_files[0],features) 
        self.column_names_for_extract_fn  = self.column_names.copy()
        self.dataset = None

        self.convert_csv_to_tfrecord()
        self.tfrecord_files = self.get_tfrecord_filenames()
        self.create_dataset()
        

    def get_csv_filenames(self):
        csv_filenames = [join(self.csv_path, f) for f in os.listdir(self.csv_path) if isfile(join(self.csv_path, f))]
        assert len(csv_filenames) > 0, "No csv files found in the given path"
        return csv_filenames
    
    def get_tfrecord_filenames(self):
        tfrecord_filenames =  [join(self.tfrecord_path, f) for f in os.listdir(self.tfrecord_path) if isfile(join(self.tfrecord_path, f))]
        assert len(tfrecord_filenames) > 0, "No tfrecord files found in the given path! probably the problem with the csv files "
        return tfrecord_filenames
    
    def get_column_names(self,csv_file,given_features):
        with open(csv_file, 'r') as file:
            column_names = file.readline().split(',')
        column_names[-1] = column_names[-1].replace('\n','')

        if given_features:
            features = given_features.copy()
            for feature in features:
                assert feature in column_names, f"{feature} not found in {csv_file}"
            return features
        return column_names
    
    def generate_tfrecord_filename(self,filename):
        tfrec_file_path = os.path.join(self.tfrecord_path, os.path.basename(filename).replace('.csv','.tfrecord')) 
        return tfrec_file_path

    def convert_csv_to_tfrecord(self):
        """creates TFRecord file for each of the csv files"""
        cn = self.column_names.copy()
        for csv_file in self.csv_files:
            try:
                tfrec_filename= self.generate_tfrecord_filename(csv_file)
                tfrec_gen = TFRecordGenerator(csv_file,tfrec_filename,cn,label_name = self.label_name,new_label_name= self.label_name_for_extract_fn,
                                            new_label_func=self.new_label_func,max_window_size =self.max_window_size,window_sizes= self.window_sizes)
                tfrec_gen.convert_to_tfrecord()
                #print(tfrec_gen.window_sizes)
                if self.window_sizes  == {}:
                    self.window_sizes = tfrec_gen.get_old_label_window_size()  ##need to get old window sizes 
                if self.new_label_func:#label name and length has been changed so we need to update
                    self.window_sizes_for_extract_fn = tfrec_gen.get_new_label_window_size()
                    self.column_names_for_extract_fn = [key for key,value in self.window_sizes_for_extract_fn.items()]
                    #print(self.window_sizes)
            except Exception as e:
                print(f'found problem with {csv_file} \n{e}')
                self.csv_files.remove(csv_file)
            
            
    def extract_fn(self,example):
        features = {
            coloum_name : tf.io.FixedLenFeature([self.window_sizes_for_extract_fn[coloum_name]], tf.float32) for coloum_name in self.column_names_for_extract_fn
        }
        
        parsed_features = tf.io.parse_example(example, features)
        #if coloumn names are feature and label (len == 2 ) return just the feature else return all fetures except label as a tuple
        features = parsed_features[self.column_names_for_extract_fn[0]] if len(self.column_names_for_extract_fn) == 2 else tuple(parsed_features[feature] for feature in self.column_names_for_extract_fn if feature not in self.label_name_for_extract_fn)

        if self.labeled:
            #label = tf.cast()
            label = []
            for l in self.label_name_for_extract_fn:
                label.append(parsed_features[l])

            #label = (parsed_features[self.label_name])
            return tf.transpose(features), tf.transpose(label)
        
        return parsed_features

    

    def create_dataset(self):
        self.dataset = tf.data.TFRecordDataset(self.tfrecord_files) 
        #self.dataset should be the same features as in extract_fn
        self.dataset = self.dataset.map(self.extract_fn)
        if self.labeled:
            self.dataset = self.dataset.prefetch(buffer_size=tf.data.AUTOTUNE)
            self.dataset = self.dataset.batch(self.batch_size)

        else:
            self.dataset = self.dataset.take(self.batch_size)

        return self.dataset
