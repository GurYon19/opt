import os 
from create_tfrecord_dataset import create_tfrecord_dataset 
from dg_utils.label_utils import two_d_to_one_d_label
import tensorflow as tf

DS_BATCH_SIZE = 16
DS_WINDOW_SIZE = 256
def get_inputs():
    curr_dir = os.getcwd()
    data_path = os.path.join(curr_dir,'Data')
    max_window_size = DS_WINDOW_SIZE # based on the column with most rows in the CSV.

    batch_size=DS_BATCH_SIZE

    #list of features to be extracted from the csv INCLUDING LABEL
    feature_list = ['Gyro1','Gyro2','Gyro3','Acc1','Acc2','Acc3','GyrButton','AccButton']  #MUST BE A LIST 
    label_name = ['GyrButton','AccButton'] #name of the label column. MUST BE A LIST 
    
    new_label_func = [two_d_to_one_d_label] #the label calculation will be when calculating the window. MUST RETURN A LIST OR NONE.
    new_label_name = None if new_label_func is None else ['label'] #name of the new label column.  MUST BE A LIST OR NONE.
    assert len(new_label_name) == len(new_label_func), f'length of label_name is {len(new_label_name)} and new_label_func is {len(new_label_func)} should be equal'
    chosen_features = feature_list # 
    #assert label_name in chosen_features, f'label name {label_name} should be in the chosen features'
    return data_path, batch_size,max_window_size,chosen_features ,label_name,new_label_name,new_label_func



def create_train_val_test_dataset(data_path, batch_size,max_window_size,chosen_features ,label_name,new_label_name,new_label_func):
    #data_path, batch_size,max_window_size,chosen_features ,label_name,new_label_name,new_label_func = get_inputs()
    print("\n Starting TFRecord Dataset creation.....\n ")
    train_dataset,val_dataset, test_dataset,_ = create_tfrecord_dataset(data_path, batch_size,max_window_size,new_label_name,new_label_func,chosen_features ,label_name)
    print("\n Finished TFRecord Dataset.....\n ")
    return train_dataset,val_dataset, test_dataset 

def get_train_val_test_dataset(data_path):

    try:
        train_dir = os.path.join(data_path,r'Train')
        train_tfrec_dir = os.path.join(train_dir,r'TFRecord')  
    except Exception as e:
        print(e)
    #get all files in the directory
    train_tfrec_files = [os.path.join(train_tfrec_dir,file) for file in os.listdir(train_tfrec_dir)]
    train_ds = tf.data.TFRecordDataset(train_tfrec_files)

    try:
        val_dir = os.path.join(data_path,r'Validation')
        val_tfrec_dir = os.path.join(val_dir,r'TFRecord')  
    except Exception as e:
        print(e)

    #get all files in the directory
    val_tfrec_files = [os.path.join(val_tfrec_dir,file) for file in os.listdir(val_tfrec_dir)]
    val_ds = tf.data.TFRecordDataset(val_tfrec_files)

    try:
        test_dir = os.path.join(data_path,r'Test')
        test_tfrec_dir = os.path.join(test_dir,r'TFRecord')
    except Exception as e:
        print(e)
    #get all files in the directory
    test_tfrec_files = [os.path.join(test_tfrec_dir,file) for file in os.listdir(test_tfrec_dir)]
    test_ds = tf.data.TFRecordDataset(test_tfrec_files)
    return train_ds,val_ds, test_ds
    
def get_datasets(data_path= None, batch_size= None,max_window_size = None,chosen_features= None ,label_name= None,new_label_name= None,new_label_func = None):
    """
    return train,val,test datasets
    """
    return create_train_val_test_dataset(data_path, batch_size,max_window_size,chosen_features ,label_name,new_label_name,new_label_func) \
        if chosen_features is not None else get_train_val_test_dataset(data_path)

if __name__ == "__main__":
    data_path, batch_size,max_window_size,chosen_features ,label_name,new_label_name,new_label_func = get_inputs()
    get_datasets(data_path, batch_size,max_window_size,chosen_features ,label_name,new_label_name,new_label_func)
    get_datasets(data_path)
