import os 
import sys

#add current directory to path


def add_to_path():
    current_dir = os.path.dirname(os.path.realpath(__file__))
    if current_dir not in sys.path:
        sys.path.append(current_dir)
    #add parent directory to path

    parent_dir = os.path.dirname(current_dir)
    if parent_dir not in sys.path:
        sys.path.append(parent_dir)



def create_tfrecord_dataset(data_path, batch_size,max_window_size,new_label_name,new_label_func,chosen_features = [],label_name = []):
    """
    Args:d
    returns tfrecord train/val/test tfrecord datasets
    """
    add_to_path()
    from tfrecord_generator.dg_utils.label_utils import set_label_length
    from tfrecord_generator.TFRecordManager import TFRecordManager
    set_label_length(len(label_name)) #set the length of the label as global var

    #TODO:get window_sizes before and pass it to all managers

    #####################
    #create train dataset
    #####################

    try:
        train_dir = os.path.join(data_path,r'Train')
        train_csv = os.path.join(train_dir,r'CSV')
        os.path.exists(train_csv)  
    except Exception as e:
        print(e)
    train_tfrec = os.path.join(train_dir,r'TFRecord')
    
    if not os.path.exists(train_tfrec):
        os.makedirs(train_tfrec)
    else:
        #remove all files in directory
        for f in os.listdir(train_tfrec):
            os.remove(os.path.join(train_tfrec, f))



    train_mngr = TFRecordManager(train_csv,train_tfrec,new_label_name,new_label_func,
                                batch_size=batch_size, max_window_size = max_window_size
                                ,labeled = True,features=chosen_features,label_name = label_name)

    
    window_sizes = train_mngr.window_sizes #dict that contains length for each coloumn/feature

    ###################
    #create val dataset
    ###################
    try:
        val_dir = os.path.join(data_path,r'Validation')
        val_csv = os.path.join(val_dir,r'CSV')  
        os.path.exists(val_csv)  
    except Exception as e:
        print(e)

    val_tfrec = os.path.join(val_dir,r'TFRecord')
    if not os.path.exists(val_tfrec):
        os.makedirs(val_tfrec)
    else:
        #remove all files in directory
        for f in os.listdir(val_tfrec):
            os.remove(os.path.join(val_tfrec, f))

    val_mngr = TFRecordManager(val_csv,val_tfrec,new_label_name,new_label_func,
                                batch_size=batch_size, max_window_size = max_window_size
                                ,labeled = True,features=chosen_features,label_name = label_name,window_sizes=window_sizes)
    
    ####################
    #create test dataset
    ####################

    try:
        test_dir = os.path.join(data_path,r'Validation')
        test_csv = os.path.join(test_dir,r'CSV')  
        os.path.exists(test_csv)  
    except Exception as e:
        print(e)

    test_tfrec = os.path.join(test_dir,r'TFRecord') 
    if not os.path.exists(test_tfrec):
        os.makedirs(test_tfrec)
    else:
        #remove all files in directory
        for f in os.listdir(test_tfrec):
            os.remove(os.path.join(test_tfrec, f))
    test_mngr = TFRecordManager(test_csv,test_tfrec,new_label_name,new_label_func,
                                batch_size=batch_size, max_window_size = max_window_size
                                ,labeled = True,features=chosen_features,label_name = label_name,window_sizes=window_sizes)#create and save dataset
    
    
    train_dataset = train_mngr.dataset
    val_dataset =  val_mngr.dataset
    test_dataset = test_mngr.dataset
    
    return train_dataset,val_dataset, test_dataset,window_sizes
    



    
    