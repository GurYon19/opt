import numpy as np

#DO NOT CHANGE THIS
def set_label_length(label_length):
    global LABEL_LENGTH
    LABEL_LENGTH = label_length


#set label calculation as you wish you must return a list or lists 




def set_label(current_list : list ) ->list: 
    
    #returns the label (list) of the window
    
    #if more than half of values in current_list are 1, then label is 1
    if np.sum(current_list) >= len(current_list)*0.8:
        label = [1]
    else:
        label = [0]
    return label
     
def two_d_to_one_d_label(labels : list) -> list:
    #converts a 2d list to 1d list
    list1 = labels[0]
    list2 = labels[1]
    result_list = [list1[i] and list2[i] for i in range(len(list1))]
    if np.sum(result_list) >= len(result_list)*0.7:
        label = [1]
    else:
        label = [0]

    
    return  label
