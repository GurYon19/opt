def normalize_list(list_to_norm):
        """
        normalize the list to [0,1]
        """
        max_value = max(list_to_norm)
        min_value = min(list_to_norm)
        return [(x-min_value)/(max_value-min_value) for x in list_to_norm]