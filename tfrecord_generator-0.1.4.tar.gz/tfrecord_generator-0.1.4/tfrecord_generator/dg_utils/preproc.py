import numpy as np
from skimage.morphology import erosion, dilation
from kymatio.keras import Scattering1D
#add here preproc function

def label_preproc_function(button):
        #change the return function as you wish
        return smooth_button(button)

def preproc_function(lst,key = None):
        return lst


# def preproc_func(list_of_windows,label_name):
#         """
#         This function is used to pre-process the data applying kymatio
#         """
#         J = 7
#         T = 128
#         Q = 4
#         scat = Scattering1D(J,T,Q)
#         pre_proc_windows = []

#         tmp_window = []
#         for window in list_of_windows:
#                 for key,value in window.items():
#                         if key not in label_name:
#                                 np_value = np.array(value)
#                                 np_value = np.expand_dims(np_value,0)
#                                 scat_input = scat(np_value)
#                                 tmp_window.append(scat_input)               
#                 proc_window_dict = {'data':tmp_window}
#                 for label in label_name:
#                         proc_window_dict[label] = window[label]
#                 pre_proc_windows.append(proc_window_dict)
#         return pre_proc_windows

def smooth_button(button):
        element1 = np.array([1, 1, 1])
        button_erode = erosion(button, element1)
        element2 = np.array([1, 1, 1, 1, 1])
        button_dilate = dilation(button_erode, element2)
        return button_dilate

def normalize_list(list_to_norm):
        """
        normalize the list to [0,1]
        """
        max_value = max(list_to_norm)
        min_value = min(list_to_norm)
        return [(x-min_value)/(max_value-min_value) for x in list_to_norm]