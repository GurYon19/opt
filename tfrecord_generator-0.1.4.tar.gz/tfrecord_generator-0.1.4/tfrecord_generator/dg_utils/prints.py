#DO NOT CHANGE THIS FUNCTION
def print_inputs(data_path, batch_size,max_window_size,chosen_features,label_name):
        print('\n')
        print(f'the data path is: {data_path}')
        print(f'the batch size is: {batch_size}')
        print(f'the max window size is: {max_window_size}')
        print(f'the chosen features are: {chosen_features}')
        print(f'the label name is: {label_name}')
        print("\n")