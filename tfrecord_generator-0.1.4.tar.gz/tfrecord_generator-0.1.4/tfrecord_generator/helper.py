"""
example :
    for the inputs
    data_path = r"C:\Users\YehonatanGurevich\Desktop\repos\TFREC_GEN\Data"
    
    max_window_size = 288 # based on the column with most rows in the CSV

    batch_size=1

    #list of features to be extracted from the csv INCLUDING LABEL
    feature_list = ['Gyro1','Gyro2','Gyro3','GyrButton','Acc1','Acc2','Acc3','AccButton'] 
    label_name = ['GyrButton','AccButton'] #name of the label column
    chosen_features = feature_list # 
    #assert label_name in chosen_features, f'label name {label_name} should be in the chosen features'
    return data_path, batch_size,max_window_size,chosen_features ,label_name

"""

"""
example for get label functions

def get_label(current_list : list ) ->list: 
    
    #returns the label (list) of the window
    
    #if more than half of values in current_list are 1, then label is 1
    if np.sum(current_list) >= len(current_list)/2:
        label = [1]
    else:
        label = [0]
    assert len(label) == LABEL_LENGTH, f'label length should be {LABEL_LENGTH}'
    return label
     
def get_label(label1:list,label2: list) -> list:
    if np.sum(label1) > len(label1)/2:
        l1 = [1]
    else:
        l1 = [0]
    if np.sum(label2) > len(label2)/2:
        l2 = 1
    else:
        l1 = 0
    label = l1 + l2
    assert len(label) == LABEL_LENGTH, f'label length should be {LABEL_LENGTH}'
    return label

"""

